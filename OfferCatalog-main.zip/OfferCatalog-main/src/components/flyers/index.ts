﻿// src/components/flyers/index.ts
export { OfferCard } from './OfferCard';
export { CatalogueCard } from './CatalogueCard';
export { SavePageButton } from './SavePageButton';
